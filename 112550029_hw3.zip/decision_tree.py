import numpy as np
import pandas as pd
from tqdm import tqdm
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import timm
from typing import List, Tuple

"""
Notice:
    1) You can't add any additional package
    2) You can add or remove any function "except" fit, _build_tree, predict
    3) You can ignore the suggested data type if you want
"""


class ConvNet(nn.Module):  # Don't change this part!
    def __init__(self):
        super(ConvNet, self).__init__()
        self.model = timm.create_model('mobilenetv3_small_100', pretrained=True, num_classes=300)

    def forward(self, x):
        x = self.model(x)
        return x


class DecisionTree:
    def __init__(self, max_depth=1):
        self.max_depth = max_depth

    def fit(self, X: pd.DataFrame, y: np.ndarray):
        self.data_size = X.shape[0]
        total_steps = 2 ** self.max_depth
        self.progress = tqdm(total=total_steps, desc="Growing tree", position=0, leave=True)
        self.tree = self._build_tree(X, y)
        self.progress.close()

    def _build_tree(self, X: pd.DataFrame, y: np.ndarray, depth: int = 0):
        if len(np.unique(y)) == 1 or depth >= self.max_depth or len(y) == 0:
            values, counts = np.unique(y, return_counts=True)
            prediction = values[np.argmax(counts)] if len(values) > 0 else None
            return {"type": "leaf", "class": prediction}
        feature, threshold = self._best_split(X, y)
        if feature is None:
            values, counts = np.unique(y, return_counts=True)
            prediction = values[np.argmax(counts)]
            return {"type": "leaf", "class": prediction}
        X_left, y_left, X_right, y_right = self._split_data(X, y, feature, threshold)
        self.progress.update(1)
        left_node = self._build_tree(X_left, y_left, depth + 1)
        right_node = self._build_tree(X_right, y_right, depth + 1)
        return {
            "type": "node",
            "feature": feature,
            "threshold": threshold,
            "left": left_node,
            "right": right_node
        }

    def predict(self, X: pd.DataFrame) -> torch.Tensor:
        preds = []
        for _, row in X.iterrows():
            preds.append(self._predict_tree(row, self.tree))
        return torch.tensor(preds)

    def _predict_tree(self, x, tree_node):
        if tree_node["type"] == "leaf":
            return tree_node["class"]
        feature = tree_node["feature"]
        threshold = tree_node["threshold"]
        value = x.iloc[feature] if hasattr(x, 'iloc') else x[feature]
        if value <= threshold:
            return self._predict_tree(x, tree_node["left"])
        else:
            return self._predict_tree(x, tree_node["right"])

    def _split_data(X: pd.DataFrame, y: np.ndarray, feature_index: int, threshold: float):
        feature_column = X.iloc[:, feature_index]
        left_mask = feature_column <= threshold
        right_mask = ~left_mask
        return X[left_mask].reset_index(drop=True), y[left_mask], X[right_mask].reset_index(drop=True), y[right_mask]

    def _best_split(X: pd.DataFrame, y: np.ndarray):
        best_gain = -float("inf")
        best_feature = None
        best_threshold = None
        current_entropy = DecisionTree._entropy(y)
        n_features = X.shape[1]
        for feature_index in range(n_features):
            values = X.iloc[:, feature_index].unique()
            for threshold in values:
                X_left, y_left, X_right, y_right = DecisionTree._split_data(X, y, feature_index, threshold)
                if len(y_left) == 0 or len(y_right) == 0:
                    continue
                p_left = len(y_left) / len(y)
                p_right = 1 - p_left
                gain = current_entropy - (
                            p_left * DecisionTree._entropy(y_left) + p_right * DecisionTree._entropy(y_right))
                if gain > best_gain:
                    best_gain = gain
                    best_feature = feature_index
                    best_threshold = threshold
        return best_feature, best_threshold

    def _entropy(y: np.ndarray) -> float:
        values, counts = np.unique(y, return_counts=True)
        probabilities = counts / counts.sum()
        epsilon = 1e-9
        entropy = -np.sum(probabilities * np.log2(probabilities + epsilon))
        return entropy


def get_features_and_labels(model: ConvNet, dataloader: DataLoader, device) -> Tuple[pd.DataFrame, np.ndarray]:
    model.eval()
    model.to(device)
    features = []
    labels = []
    with torch.no_grad():
        for images, labs in tqdm(dataloader, desc="Extracting features"):
            images = images.to(device)
            output = model(images)
            features.extend(output.cpu().numpy())
            if isinstance(labs, torch.Tensor):
                labels.extend(labs.cpu().numpy())
            else:
                labels.extend(labs)
    return pd.DataFrame(features), np.array(labels)


def get_features_and_paths(model: ConvNet, dataloader: DataLoader, device) -> Tuple[pd.DataFrame, List]:
    model.eval()
    model.to(device)
    features = []
    paths = []
    with torch.no_grad():
        for images, img_paths in tqdm(dataloader, desc="Extracting features"):
            images = images.to(device)
            output = model(images)
            features.extend(output.cpu().numpy())
            paths.extend(img_paths)
    return pd.DataFrame(features), paths

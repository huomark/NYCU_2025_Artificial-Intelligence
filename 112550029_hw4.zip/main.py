import Agent as Agent 
import numpy as np
import BanditEnv as BanditEnv
import matplotlib.pyplot as plt

k = 10
n_runs = 2000
n_episodes = 10000
epsilons = [0, 0.01, 0.1]

avg_rewards = {}
optimal_counts_2 = {}

for epsilon in epsilons:
    rewards = np.zeros(n_episodes)
    optimal_counts = np.zeros(n_episodes)

    for _ in range(n_runs):
        agent = Agent.Agent(k, epsilon, 0.1)
        env = BanditEnv.BanditEnv(k, False)
        env.reset()
        agent.reset()

        for t in range(n_episodes):
            optimal_arm = np.argmax(env.q_values)
            action = agent.select_action()
            reward = env.step(action)
            agent.update_q(action, reward)
            rewards[t] += reward

            if action == optimal_arm:
                optimal_counts[t] += 1


    avg_rewards[epsilon] = rewards / n_runs
    optimal_counts_2[epsilon] = optimal_counts / n_runs * 100


for epsilon in epsilons:
    plt.plot(avg_rewards[epsilon], label=f'ε = {epsilon}')
plt.xlabel('Step')
plt.ylabel('Average Reward')
plt.title('Average Reward Over Time')
plt.legend()
plt.grid(True)
plt.show()


for epsilon in epsilons:
    plt.plot(optimal_counts_2[epsilon], label=f'ε = {epsilon}')
plt.xlabel('Step')
plt.ylabel('% Optimal Action')
plt.title('Optimal Action Percentage Over Time')
plt.legend()
plt.grid(True)
plt.show()

import numpy as np

class Agent:
    def __init__(self, n_arms, epsilon, alpha=None):
        self.n_arms = n_arms
        self.epsilon = epsilon
        self.alpha = alpha
        self.q_values = np.zeros(n_arms, dtype=np.float64)
        self.action_counts = np.zeros(n_arms)

    def select_action(self):
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.n_arms)
        else:
            return np.argmax(self.q_values)

    def update_q(self, action, reward):
        now = self.q_values[action]
        self.q_values[action] = self.q_values[action] * self.action_counts[action] + reward
        self.q_values[action] /= (self.action_counts[action] + 1)
        self.action_counts[action] += 1
        if self.alpha != None:
            self.q_values[action] = now + (reward - now) * self.alpha


    def reset(self):
        self.q_values.fill(0)
        self.action_counts.fill(0)
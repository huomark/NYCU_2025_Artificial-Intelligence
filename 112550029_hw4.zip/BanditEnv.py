import numpy as np

class BanditEnv:
    def __init__(self, n_arms, stationary = True):
        self.n_arms = n_arms
        self.q_values = np.zeros(n_arms)
        self.action_counts = [0] * n_arms
        self.action_history = []
        self.reward_history = []
        self.stationary = stationary
        

    def reset(self):
        self.q_values = np.zeros(self.n_arms)
        for i in range(self.n_arms):
            self.q_values[i] = np.random.normal()
        self.action_counts = [0] * self.n_arms
        self.action_history = []
        self.reward_history = []

    def step(self, action):
        reward = self.q_values[action] + np.random.normal()
        if not self.stationary:
            self.q_values += np.random.normal(0, 0.01, self.n_arms)
        self.action_counts[action] += 1
        self.action_history.append(action)
        self.reward_history.append(reward)
        return reward

    def export_history(self):
        return self.action_history, self.reward_history